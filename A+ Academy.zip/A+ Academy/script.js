document.querySelector('.visit-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Your visit is successfully booked! We look forward to seeing you.');
});


// Select all image containers
const imageContainers = document.querySelectorAll('.image-container');

// Add click event to each image container
imageContainers.forEach(container => {
    container.addEventListener('click', () => {
        // Remove 'clicked' class from all containers
        imageContainers.forEach(item => item.classList.remove('clicked'));
        // Add 'clicked' class to the clicked container
        container.classList.add('clicked');
    });
});






// Select all accordion headers
const accordionHeaders = document.querySelectorAll('.accordion-header');

// Add event listeners to toggle the visibility of the accordion body
accordionHeaders.forEach(header => {
    header.addEventListener('click', () => {
        const accordionBody = header.nextElementSibling;

        // Close all other accordion bodies
        document.querySelectorAll('.accordion-body').forEach(body => {
            if (body !== accordionBody) {
                body.style.display = 'none';
            }
        });

        // Toggle the clicked accordion body
        accordionBody.style.display =
            accordionBody.style.display === 'block' ? 'none' : 'block';
    });
});
